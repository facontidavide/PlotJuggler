^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package data_tamer_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.0.3 (2025-05-23)
-----------
* No changes

1.0.2 (2025-05-12)
-----------
* Merge pull request `#49 <https://github.com/PickNikRobotics/data_tamer/issues/49>`_ from PickNikRobotics/fix_gtest_link
  Get gtest from vendor on ROS
* add myself to maintainer list, add package xml scheme
* Contributors: Henry Moore

1.0.1 (2025-03-03)
------------------

1.0.0 (2024-04-30)
------------------
* new clang format
* Contributors: Davide Faconti

0.9.4 (2024-02-02)
------------------

0.9.3 (2024-02-01)
------------------

0.9.2 (2024-01-30)
------------------

0.9.1 (2024-01-12)
------------------

0.8.0 (2023-11-30)
------------------
* Merge branch 'dev'
* Contributors: Davide Faconti

0.7.0 (2023-11-28)
------------------

0.6.0 (2023-11-23)
------------------
* works correctly with plotjuggler
* fix ROS2 compilation
* Contributors: Davide Faconti

0.5.0 (2023-11-22)
------------------

0.4.1 (2023-11-21)
------------------

0.4.0 (2023-11-21)
------------------

0.3.0 (2023-11-14)
------------------
* Merge branch 'humble_dev'
* more compact schema
* Contributors: Davide Faconti

0.2.1 (2023-11-13)
------------------

0.2.0 (2023-11-13)
------------------
* Enable ROS2
* Contributors: Davide Faconti
